let animalImg = document.querySelector("#fav_animal");

function pickcat() {
  animalImg.src = "./static/cat pic.jpg";
}

function pickdog() {
  animalImg.src = "./static/dog pic.jpg";
}
/* TURNOFF
function turnoff(element) {
 element.innerText = "Off"
} */

/* mouseover removing action and adding action

function addShadow(element) {
  element.classList.add("shadow") ;
}

function removeShadow(element) {
  element.classList.remove("shadow");
}
 */

/* ADD & SUBTRACT 
var count = 1;
var countElement = document.querySelector("#count");

function add1() {
  count ++;
  console.log(count)
  countElement.innerText = "The count is" + count;
}



function subtract1() {
  count --;
  console.log(count)
  countElement.innerText = "The count is" + count;
} */

